drop table "user" cascade;
drop table category cascade;
drop table menu cascade;
drop table evaluation cascade;
drop table daymenu cascade;
